Convertly archive fixture
